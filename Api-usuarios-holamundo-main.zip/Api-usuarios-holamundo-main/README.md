```properties
spring_profiles_active=
PROD_DB_HOST=
PROD_DB_PORT=
PROD_DB_NAME=
PROD_DB_PASSWORD=
PROD_DB_USERNAME=
```
