const sections = [
    { name: "🏠 Inicio", url: "/" },
    { name: "Acerca de", url: "/p/about" },
    { name: "Artículos", url: "/blog" },
];

export default sections;
