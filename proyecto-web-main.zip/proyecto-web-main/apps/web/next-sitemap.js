module.exports = {
    siteUrl: "",
    generateRobotsTxt: true,
    exclude: [

    ],
};
