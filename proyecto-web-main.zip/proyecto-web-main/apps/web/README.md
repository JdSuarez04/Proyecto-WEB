# hola mundo

> website/blog

[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=flat-square)]()

![](https://pbs.twimg.com/media/FY1-1sMXwAARRdf.jpg)

## Como instalar proyecto

```shell
npm instal
```

## Correr en desarrollo

```shell
npm run dev
```

## Integrantes

- Daniel Valencia
- Dana borrero
- Juan Suarez


## Technologies

- Next.js
- React.js
- @emotion/styled
- ChakraUI
- MarkdownX
- Vercel

## Support

[Github](https://github.com/dalejandrov)
