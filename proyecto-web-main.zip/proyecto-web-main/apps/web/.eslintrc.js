module.exports = {
  root: true,
  extends: ["czstr"],
};
